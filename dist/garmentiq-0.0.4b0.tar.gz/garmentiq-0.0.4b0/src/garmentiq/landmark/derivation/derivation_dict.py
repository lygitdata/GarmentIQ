derivation_dict = {
    "derive_keypoint_coord": {
        "p1_id": None,
        "p2_id": None,
        "p3_id": None,
        "p4_id": None,
        "p5_id": None,
        "direction": ["parallel", "perpendicular"],
    }
}