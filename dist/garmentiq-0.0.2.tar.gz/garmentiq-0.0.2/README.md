# GarmentIQ: Automated Garment Measurement for Fashion Retail

Underdevelopment