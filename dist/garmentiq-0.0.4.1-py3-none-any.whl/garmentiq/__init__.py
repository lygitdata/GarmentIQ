# garmentiq/__init__.py
from .tailor import tailor
from . import utils
from . import classification
from . import segmentation
from . import landmark
