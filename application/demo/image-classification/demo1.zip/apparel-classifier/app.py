import torch
import torch.nn as nn
from torchvision import transforms
from PIL import Image
from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import warnings
warnings.filterwarnings("ignore", category=UserWarning, module="torch")

app = Flask(__name__)
CORS(app)

# Define model architecture first
class CNN(nn.Module):
    def __init__(self, num_classes=5):
        super(CNN, self).__init__()
        self.features = nn.Sequential(
            # Block 1
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.Conv2d(64, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Dropout(0.25),

            # Block 2
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.Conv2d(128, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Dropout(0.25),

            # Block 3
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d((4, 6))
        )

        self.classifier = nn.Sequential(
            nn.Linear(256 * 4 * 6, 512),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, 256),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes)
        )

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x
     

# Initialize model and transformations
CLASS_NAMES = ['Dress', 'Pants', 'Skirt', 'Sleeveless top', 'Top']
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = CNN(num_classes=5).to(device)
transform = transforms.Compose([
    transforms.Resize((60, 80)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

def load_model():
    model_path = os.path.join(os.path.dirname(__file__), 'model.pth')
    state_dict = torch.load(model_path, map_location=device, weights_only=True)
    new_state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
    model.load_state_dict(new_state_dict, strict=False)
    model.eval()

load_model()

@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
        
    file = request.files['file']
    try:
        image = Image.open(file).convert('RGB')
        tensor = transform(image).unsqueeze(0).to(device)
        
        load_model()

        with torch.no_grad():
            outputs = model(tensor)
            _, preds = torch.max(outputs, 1)

        return jsonify({
            "prediction": CLASS_NAMES[preds[0].item()],
            "confidence": torch.nn.functional.softmax(outputs, dim=1)[0][preds[0]].item(),
            "device": str(device)
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health')
def health_check():
    return jsonify({
        "status": "active",
        "token": "fe9def684914b305540615b3bba461fbf8ea58f460c72b1fe128d3cef93fe4f8",
        "model": "ApparelClassifier",
        "version": "1.0.0"
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)